from flask import Flask
from models import Movie, Song, Artist, db
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///music.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)


if __name__ == '__main__':
    with app.app_context():
        db.create_all()

        movie1 = Movie(title='Hancock', director='Peter Berg', release_year=2008, genre='Science fiction, Action, Drama, Comedy')
        movie2 = Movie(title='1+1', director='Éric Toledano and Olivier Nakache', release_year=2011, genre='Drama, Comedy')

        song1 = Song(title='Биография', length='1:40', album='Классика', artist='artist2')
        song2 = Song(title='ПРОБЛЕМЫ С...', length='1:32', album='ПРОБЛЕМЫ С...', artist='artist1')

        artist1 = Artist(name='МС БАТОН')
        artist2 = Artist(name='ДЖОН ГАРИК')

        db.session.add_all([artist1, artist2, movie1, movie2, song1, song2])
        db.session.commit()